

import React, { useState, useCallback, useEffect } from 'react';
import { RACES, CLASSES, BACKGROUNDS, SKIN_COLORS, GENDERS, HAIR_TYPES, TERRAINS, ENEMIES, FIGHTING_STYLES, SKILLS, ALIGNMENTS, HAIR_COLORS, CLOTH_THEMES, Theme, MAX_CHARACTERS } from './constants';
import { CharacterOptions, FinalCharacter, StoryEvent, SavedGameState, Campaign } from './types';
import CharacterCustomizer from './components/CharacterCustomizer';
import CharacterSheet from './components/CharacterSheet';
import StoryGame from './components/StoryGame';
import OpeningPage from './components/OpeningPage';
import CharacterTabs from './components/CharacterTabs';
import MainCharacterModal from './components/MainCharacterModal';
import { generateBackgroundStory, generateCharacterName } from './services/geminiService';
import { createFinalCharacter, getRandomElement, generateRandomStats, getRandomSkills, saveGameStateAsJson } from './utils.ts';
import { LocalizationProvider } from './contexts/LocalizationContext';
import { useLocalization } from './contexts/LocalizationContext';
import LanguageSwitcher from './components/LanguageSwitcher';

const GAME_STATE_VERSION = "1.0";

const defaultOptions: CharacterOptions = {
    name: '',
    race: RACES[0],
    characterClass: CLASSES[0],
    background: BACKGROUNDS[0],
    alignment: ALIGNMENTS[4],
    gender: GENDERS[0],
    hairType: HAIR_TYPES[0],
    hairColor: HAIR_COLORS[0],
    skinColor: SKIN_COLORS[0],
    clothColor: CLOTH_THEMES[0].name,
    height: 50,
    build: 50,
    muscularity: 50,
    favoriteTerrain: TERRAINS[0],
    favoriteEnemy: ENEMIES[0],
    stats: { strength: 8, dexterity: 8, constitution: 8, intelligence: 8, wisdom: 8, charisma: 8 },
    backgroundStory: '',
    selectedSkills: [],
    fightingStyle: FIGHTING_STYLES[0],
    customSpecialMove: '',
};

const GameContent: React.FC<{ lang: 'en' | 'id'; initialGameState: string | null; t: (key: string, options?: any) => string; setOpeningPageError: (error: string | null) => void, campaign: Campaign; onResetGame: () => void; }> = ({ lang, initialGameState, t, setOpeningPageError, campaign, onResetGame }) => {
  const [characters, setCharacters] = useState<FinalCharacter[]>([]);
  const [activeCharacterIndex, setActiveCharacterIndex] = useState<number | null>(null);
  const [mainCharacterIndex, setMainCharacterIndex] = useState<number | null>(null);
  const [view, setView] = useState<'dashboard' | 'creator' | 'story'>('dashboard');
  
  const [creatorOptions, setCreatorOptions] = useState<CharacterOptions>(defaultOptions);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isRandomizing, setIsRandomizing] = useState<boolean>(false);
  const [isGeneratingStory, setIsGeneratingStory] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isMainCharModalOpen, setIsMainCharModalOpen] = useState(false);
  const [storyLog, setStoryLog] = useState<StoryEvent[]>([]);

  const handleLoadGame = useCallback((jsonString: string) => {
    try {
      const savedState: SavedGameState = JSON.parse(jsonString);
      if (savedState.version !== GAME_STATE_VERSION || !savedState.characters || !savedState.storyLog) {
          throw new Error("Invalid or incompatible save file.");
      }
      setCharacters(savedState.characters);
      setStoryLog(savedState.storyLog);
      setMainCharacterIndex(savedState.mainCharacterIndex);
      setActiveCharacterIndex(savedState.mainCharacterIndex); // Focus main char on load
      setView('story');
      setError(null);
    } catch (e) {
      console.error("Failed to load game state", e);
      setOpeningPageError(t('errorLoadingGame'));
    }
  }, [t, setOpeningPageError]);

  useEffect(() => {
    if (initialGameState) {
      handleLoadGame(initialGameState);
    }
  }, [initialGameState, handleLoadGame]);
  
  // THEME MANAGEMENT
  useEffect(() => {
    let currentTheme: Theme | undefined;

    if (view === 'creator') {
      currentTheme = CLOTH_THEMES.find(t => t.name === creatorOptions.clothColor);
    } else if (activeCharacterIndex !== null && characters[activeCharacterIndex]) {
      currentTheme = CLOTH_THEMES.find(t => t.name === characters[activeCharacterIndex].clothColor);
    }

    if (!currentTheme) {
      currentTheme = CLOTH_THEMES[0]; // Default theme
    }
    
    const root = document.documentElement;
    root.style.setProperty('--color-accent', currentTheme.accent);
    root.style.setProperty('--color-accent-dark', currentTheme.accentDark);
    root.style.setProperty('--color-accent-light', currentTheme.accentLight);
    root.style.setProperty('--color-text-on-accent', currentTheme.textOnAccent);
    root.style.setProperty('--color-text-heading', currentTheme.accentLight);

    document.body.style.background = `linear-gradient(to bottom right, ${currentTheme.from}, ${currentTheme.via}, ${currentTheme.to})`;

  }, [view, creatorOptions.clothColor, activeCharacterIndex, characters]);


  useEffect(() => {
    if (characters.length === 0 && view !== 'creator' && !initialGameState) {
        setView('creator');
        setActiveCharacterIndex(null);
    } else if (characters.length > 0 && view === 'creator' && editingIndex === null) {
        // This logic is tricky. Let's simplify: if we are not in story mode, and characters exist, go to dashboard.
    } else if (characters.length > 0 && view !== 'story') {
       setView('dashboard');
       if (activeCharacterIndex === null || activeCharacterIndex >= characters.length) {
            setActiveCharacterIndex(0);
       }
    }
  }, [characters.length, initialGameState]);

  const handleSaveCharacter = async (optionsToSave: CharacterOptions) => {
    setIsLoading(true);
    setError(null);
    try {
      const finalCharacter = await createFinalCharacter(optionsToSave, lang, t);
      
      let newCharIndex = 0;
      setCharacters(prev => {
          if (editingIndex !== null) {
              const newChars = [...prev];
              newChars[editingIndex] = finalCharacter;
              newCharIndex = editingIndex;
              return newChars;
          } else {
              const newChars = [...prev, finalCharacter];
              newCharIndex = newChars.length - 1;
              return newChars;
          }
      });

      setActiveCharacterIndex(newCharIndex);
      setEditingIndex(null);
      setView('dashboard');

    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'An unknown error occurred. Please check the console.');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleRandomGenerate = async () => {
    setIsRandomizing(true);
    setError(null);
    try {
      const race = getRandomElement(RACES);
      const characterClass = getRandomElement(CLASSES);
      const gender = getRandomElement(GENDERS);
      const name = await generateCharacterName({ race, characterClass, gender }, lang);

      const randomOptions: CharacterOptions = {
          name, race, characterClass, gender,
          background: getRandomElement(BACKGROUNDS),
          alignment: getRandomElement(ALIGNMENTS),
          hairType: getRandomElement(HAIR_TYPES),
          hairColor: getRandomElement(HAIR_COLORS),
          skinColor: getRandomElement(SKIN_COLORS),
          clothColor: getRandomElement(CLOTH_THEMES).name,
          height: Math.floor(Math.random() * 101),
          build: Math.floor(Math.random() * 101),
          muscularity: Math.floor(Math.random() * 101),
          favoriteTerrain: getRandomElement(TERRAINS),
          favoriteEnemy: getRandomElement(ENEMIES),
          stats: generateRandomStats(),
          backgroundStory: '', 
          selectedSkills: getRandomSkills(SKILLS, 4),
          fightingStyle: getRandomElement(FIGHTING_STYLES),
          customSpecialMove: '',
      };
      
      setCreatorOptions(randomOptions);

    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : t('errorRandomizing'));
    } finally {
      setIsRandomizing(false);
    }
  };

  const handleGenerateStory = useCallback(async () => {
    setIsGeneratingStory(true);
    try {
        const story = await generateBackgroundStory(creatorOptions, lang);
        setCreatorOptions(prev => ({...prev, backgroundStory: story}));
    } catch (err) {
        console.error("Error generating story", err);
    } finally {
        setIsGeneratingStory(false);
    }
  }, [creatorOptions, lang]);

  const handleUploadCharacter = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
        try {
            const json = event.target?.result;
            if (typeof json === 'string') {
                const loadedCharacter: FinalCharacter = JSON.parse(json);
                if (loadedCharacter.race && loadedCharacter.characterClass && loadedCharacter.stats) {
                    if (!loadedCharacter.inventory) loadedCharacter.inventory = [];
                    if (loadedCharacter.inventory.length > 0 && typeof loadedCharacter.inventory[0] === 'string') {
                        loadedCharacter.inventory = (loadedCharacter.inventory as unknown as string[]).map(name => ({ name }));
                    }
                    if (!loadedCharacter.mainWeapon) loadedCharacter.mainWeapon = null;
                    if (!loadedCharacter.armor) loadedCharacter.armor = null;

                    setCharacters(prev => [...prev, loadedCharacter].slice(0, MAX_CHARACTERS));
                    setActiveCharacterIndex(characters.length);
                    setView('dashboard');
                    setError(null);
                } else {
                    throw new Error(t('errorInvalidCharacterFile'));
                }
            }
        } catch (e) {
            console.error("Failed to load or parse character file", e);
            setError(t('errorLoadingCharacterFile'));
        }
    };
    reader.readAsText(file);
  };
  
  const handleSaveGame = () => {
    if (mainCharacterIndex === null) return;
    const gameState: SavedGameState = {
        version: GAME_STATE_VERSION,
        characters,
        storyLog,
        mainCharacterIndex,
        campaign: campaign,
    };
    saveGameStateAsJson(gameState);
  };

  const handleAddNewCharacter = () => {
      setEditingIndex(null);
      setCreatorOptions(defaultOptions);
      setError(null);
      setView('creator');
  };

  const handleEditCharacter = (index: number) => {
      const charToEdit = characters[index];
      const { generated, image, inventory, mainWeapon, armor, currency, notes, maxHp, currentHp, armorClass, ...optionsFromChar } = charToEdit;
      setCreatorOptions(optionsFromChar);
      setEditingIndex(index);
      setError(null);
      setView('creator');
  };
  
  const handleDeleteCharacter = (index: number) => {
    const charName = characters[index].name || 'this character';
    if (window.confirm(`${t('confirmDelete')} ${charName}?`)) {
      setCharacters(prev => prev.filter((_, i) => i !== index));
      if (activeCharacterIndex === index) {
          const newIndex = Math.max(0, index - 1);
          setActiveCharacterIndex(characters.length > 1 ? newIndex : null);
      } else if (activeCharacterIndex && activeCharacterIndex > index) {
          setActiveCharacterIndex(activeCharacterIndex - 1);
      }
    }
  };

  const handleCharacterChange = useCallback((index: number) => {
      setActiveCharacterIndex(index);
  }, []);
  
  const handleStartStory = (characterIndex: number) => {
    setStoryLog([]); // Clear previous story
    setActiveCharacterIndex(characterIndex);
    if (characters.length > 1) {
        setIsMainCharModalOpen(true);
    } else {
        setMainCharacterIndex(characterIndex);
        setView('story');
    }
  }

  const handleConfirmMainCharacter = (charIndex: number) => {
    setCharacters(prev => {
        const newOrder = [...prev];
        const mainChar = newOrder.splice(charIndex, 1)[0];
        newOrder.unshift(mainChar);
        return newOrder;
    });
    setMainCharacterIndex(0);
    setActiveCharacterIndex(0);
    setIsMainCharModalOpen(false);
    setView('story');
  };

  const renderContent = () => {
    if (view === 'creator') {
      return (
          <div className="max-w-3xl mx-auto animate-fade-in">
              {error && <div className="bg-red-500/20 text-red-300 p-3 rounded-lg mb-4 text-center">{error}</div>}
              <CharacterCustomizer 
                options={creatorOptions}
                setOptions={setCreatorOptions}
                isLoading={isLoading}
                isRandomizing={isRandomizing}
                isGeneratingStory={isGeneratingStory}
                onGenerate={() => handleSaveCharacter(creatorOptions)}
                onRandomGenerate={handleRandomGenerate}
                onGenerateStory={handleGenerateStory}
                onUpload={handleUploadCharacter}
                onBack={() => characters.length > 0 ? setView('dashboard') : null}
                isEditing={editingIndex !== null}
              />
          </div>
      );
    }
    
    if (view === 'dashboard' && activeCharacterIndex !== null && characters[activeCharacterIndex]) {
      const activeCharacter = characters[activeCharacterIndex];
      return <CharacterSheet
              character={activeCharacter}
              onEdit={() => handleEditCharacter(activeCharacterIndex)}
              onStartStory={() => handleStartStory(activeCharacterIndex)}
            />
    }

    if (view === 'story' && activeCharacterIndex !== null && mainCharacterIndex !== null) {
      return <StoryGame 
                characters={characters}
                setCharacters={setCharacters}
                activeCharacterIndex={activeCharacterIndex}
                onCharacterChange={handleCharacterChange}
                mainCharacterIndex={mainCharacterIndex}
                lang={lang}
                storyLog={storyLog}
                setStoryLog={setStoryLog}
                onSaveGame={handleSaveGame}
                onExitStory={onResetGame}
                campaign={campaign}
             />
    }

    return (
        <div className="text-center py-20 animate-fade-in">
            <h2 className="text-4xl font-bold font-medieval text-text-heading">{t('welcomeAdventurer')}</h2>
            <p className="text-accent-light/80 mt-2 text-lg">{t('journeyBegins')}</p>
            <button onClick={handleAddNewCharacter} className="mt-8 bg-gradient-to-br from-accent to-accent-dark text-text-on-accent font-bold py-3 px-6 rounded-lg hover:from-accent-dark hover:to-accent-dark transition-all duration-300 text-xl tracking-wider">
                {t('createFirstCharacter')}
            </button>
        </div>
    );
  };

  return (
    <div className="min-h-screen text-text-main p-4 sm:p-6 lg:p-8 font-sans">
      <div className="container mx-auto">
        <header className="flex items-center justify-between mb-4">
            <div className="flex-1"></div>
            <div className="text-center">
                <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold tracking-wider font-medieval bg-gradient-to-b from-accent-light to-accent-dark bg-clip-text text-transparent">D&D Story Game</h1>
                <p className="text-accent-light/80 mt-2 text-lg">
                    {characters.length > 0 && view !== 'story' ? t('adventureAwaits') : t('craftYourHero')}
                </p>
            </div>
            <div className="flex-1 flex justify-end">
            </div>
        </header>

        {characters.length > 0 && view === 'dashboard' && (
             <CharacterTabs 
                characters={characters}
                activeIndex={activeCharacterIndex}
                onSelect={(index) => setActiveCharacterIndex(index)}
                onAdd={handleAddNewCharacter}
                onDelete={handleDeleteCharacter}
                addLabel={t('addCharacter')}
                canAdd={characters.length < MAX_CHARACTERS}
             />
        )}
        
        <main>
          {renderContent()}
        </main>
        
        {isMainCharModalOpen && (
            <MainCharacterModal
                characters={characters}
                onConfirm={handleConfirmMainCharacter}
                onCancel={() => setIsMainCharModalOpen(false)}
            />
        )}
      </div>
    </div>
  );
};

const App: React.FC = () => {
    const [lang, setLang] = useState<'en' | 'id'>('en');
    const [campaign, setCampaign] = useState<Campaign>('lost-mine-of-phandelver');
    const [isGameActive, setIsGameActive] = useState(false);
    const [initialGameState, setInitialGameState] = useState<string | null>(null);
    const [openingPageError, setOpeningPageError] = useState<string | null>(null);

    const handleStartNewGame = (selectedCampaign: Campaign) => {
        setCampaign(selectedCampaign);
        setInitialGameState(null);
        setOpeningPageError(null);
        setIsGameActive(true);
    };

    const handleLoadGame = (jsonString: string) => {
        const savedState: SavedGameState = JSON.parse(jsonString);
        setCampaign(savedState.campaign || 'lost-mine-of-phandelver');
        setInitialGameState(jsonString);
        setOpeningPageError(null);
        setIsGameActive(true);
    };
    
    const handleResetGame = () => {
        setIsGameActive(false);
        setInitialGameState(null);
        setOpeningPageError(null);
    };
    
    // Set a default theme for the opening page
     useEffect(() => {
        const theme = CLOTH_THEMES[0];
        const root = document.documentElement;
        root.style.setProperty('--color-accent', theme.accent);
        root.style.setProperty('--color-accent-dark', theme.accentDark);
        root.style.setProperty('--color-accent-light', theme.accentLight);
        root.style.setProperty('--color-text-on-accent', theme.textOnAccent);
        root.style.setProperty('--color-text-heading', theme.accentLight);
        document.body.style.background = `linear-gradient(to bottom right, ${theme.from}, ${theme.via}, ${theme.to})`;
    }, [isGameActive]);

    return (
        <LocalizationProvider lang={lang}>
            {!isGameActive ? (
                <OpeningPage onStart={handleStartNewGame} onLoad={handleLoadGame} error={openingPageError} setLang={setLang} />
            ) : (
                <>
                    <LanguageSwitcher setLang={setLang} />
                    <GameContentWrapper lang={lang} campaign={campaign} initialGameState={initialGameState} onResetGame={handleResetGame} setOpeningPageError={(error) => {
                        setOpeningPageError(error);
                        setIsGameActive(false);
                    }} />
                </>
            )}
        </LocalizationProvider>
    );
};

// This wrapper is needed to use the useLocalization hook for passing 't' to GameContent
const GameContentWrapper: React.FC<{
  lang: 'en' | 'id';
  campaign: Campaign;
  initialGameState: string | null;
  setOpeningPageError: (error: string | null) => void;
  onResetGame: () => void;
}> = ({ lang, campaign, initialGameState, setOpeningPageError, onResetGame }) => {
  const { t } = useLocalization();
  return <GameContent lang={lang} campaign={campaign} initialGameState={initialGameState} t={t} setOpeningPageError={setOpeningPageError} onResetGame={onResetGame} />;
};

export default App;
