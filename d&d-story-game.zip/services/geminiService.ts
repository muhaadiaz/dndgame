
import { GoogleGenAI, Type, Chat, Content } from "@google/genai";
import { CharacterOptions, GeneratedData, FinalCharacter, StoryEvent, Campaign } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

function getHeightDescription(value: number, lang: 'en' | 'id'): string {
    const descriptions = {
        en: ["very short", "short", "average height", "tall", "very tall"],
        id: ["sangat pendek", "pendek", "tinggi rata-rata", "tinggi", "sangat tinggi"]
    };
    if (value < 20) return descriptions[lang][0];
    if (value < 40) return descriptions[lang][1];
    if (value < 60) return descriptions[lang][2];
    if (value < 80) return descriptions[lang][3];
    return descriptions[lang][4];
}

function getBuildDescription(value: number, lang: 'en' | 'id'): string {
    const descriptions = {
        en: ["very thin and slender", "thin", "of average build", "muscular and thick", "very large and bulky"],
        id: ["sangat kurus dan langsing", "kurus", "bertubuh rata-rata", "berotot dan berisi", "sangat besar dan kekar"]
    };
    if (value < 20) return descriptions[lang][0];
    if (value < 40) return descriptions[lang][1];
    if (value < 60) return descriptions[lang][2];
    if (value < 80) return descriptions[lang][3];
    return descriptions[lang][4];
}

function getMuscularityDescription(value: number, lang: 'en' | 'id'): string {
    const descriptions = {
        en: ["very lean", "toned", "moderately muscular", "very muscular", "extremely bulky and powerful"],
        id: ["sangat ramping", "kencang", "cukup berotot", "sangat berotot", "sangat kekar dan kuat"]
    };
    if (value < 20) return descriptions[lang][0];
    if (value < 40) return descriptions[lang][1];
    if (value < 60) return descriptions[lang][2];
    if (value < 80) return descriptions[lang][3];
    return descriptions[lang][4];
}

const getSystemInstruction = (campaign: Campaign, party: FinalCharacter[], mainCharacterIndex: number, lang: 'en' | 'id'): string => {
    const mainCharacter = party[mainCharacterIndex];
    const otherCharacters = party.filter((_, index) => index !== mainCharacterIndex);

    const commonRules = {
        en: `**CORE DM RULES - VERY IMPORTANT:**

1.  **NEVER Decide Outcomes Directly:** Your primary job is to describe the situation and ask the player what they want to do. For any action where the outcome is uncertain (attacking, persuading, sneaking, investigating, climbing, etc.), you **MUST** ask the player to make a specific dice roll, usually a **d20**.
2.  **Request Specific Rolls:** Tell the player exactly what to roll. For example:
    *   "Okay, roll a **d20** for a Dexterity (Stealth) check to see if you can sneak past."
    *   "He seems skeptical. Roll a **d20** for a Charisma (Persuasion) check."
    *   "The goblin attacks! Roll a **d20** for a melee attack roll."
    *   "You'll need to roll a **d20** for a DC 15 Strength (Athletics) check to climb that cliff."
3.  **Interpret Roll Results:** After the player provides their roll result, narrate the outcome.
    *   A roll of **1** is a **Critical Failure**. Something comically or disastrously bad happens.
    *   A roll of **20** on a d20 is a **Critical Success** (for attacks and saving throws). The character succeeds spectacularly.
    *   For checks against a DC, a roll equal to or higher than the DC is a success. A roll lower is a failure. Describe the degree of success or failure.
4.  **Item Acquisition:** When a character acquires a new item, you MUST format it in your response like this: **ITEM:[Item Name] (Tag: [Tag])**. For example: "You find a potion of healing, ITEM:Potion of Healing (Tag: Consumable)."
5.  **Combat Mode - VERY IMPORTANT:**
    *   **Starting Combat:** When combat begins, you MUST start your response with the tag \`COMBAT_START:[Width]x[Height]\`. Example: \`COMBAT_START:10x10\`. This activates the tactical map.
    *   **Placing Units:** Immediately after starting combat, place all characters and enemies on the map using the update tag.
    *   **Updating Positions:** Every time a character or enemy moves or acts in a way that changes the tactical situation, you MUST include the tag \`COMBAT_UPDATE:[Unit1Name]@([X],[Y]),[Unit2Name]@([X],[Y])\`. Example: \`COMBAT_UPDATE:Goblin 1@(3,4),${mainCharacter.name}@ (5,5)\`.
        - The top-left corner is (1,1).
        - Ensure unit names are consistent. For enemies, use names like "Goblin 1", "Goblin 2", "Ogre".
        - You can update multiple units in one tag.
    *   **Ending Combat:** When combat is over (all enemies defeated or fled), you MUST start your response with the tag \`COMBAT_END\`. This deactivates the map.
6.  **Narrative Focus:** Always narrate from the perspective of the Main Character, ${mainCharacter.name}. Address them as "You". Other party members are Companions who you control.
7.  **Party Information:**
    - **Main Character:** ${mainCharacter.name} (${mainCharacter.race} ${mainCharacter.characterClass}).
      - Appearance: ${mainCharacter.generated.characterDescription}
      - Stats: Str ${mainCharacter.stats.strength}, Dex ${mainCharacter.stats.dexterity}, Con ${mainCharacter.stats.constitution}, Int ${mainCharacter.stats.intelligence}, Wis ${mainCharacter.stats.wisdom}, Cha ${mainCharacter.stats.charisma}
      - Backstory: ${mainCharacter.backgroundStory}
    - **Companions:** ${otherCharacters.length > 0 ? otherCharacters.map(c => `${c.name} (${c.race} ${c.characterClass})`).join(', ') : 'None'}.
    - **Party Size:** ${party.length} (Max 5).
8.  **Unit System:** Use imperial units (feet, pounds) for descriptions. The tactical grid represents this visually.
9.  **Introduce Companions:** To offer a new companion, first describe the character and have them make the offer conversationally. Then, you **MUST** place this exact tag on a new line immediately after: \`INVITE_CHARACTER:[Name],[Race],[Class],[Gender]\`. This tag triggers interactive buttons. Only do this if the party has less than 5 members. Example: The dwarf grunts, "I'm heading to the caves too. Safer to travel together. Mind if I join you?"\nINVITE_CHARACTER:Boric,Dwarf,Fighter,Male`,
        id: `**ATURAN INTI DM - SANGAT PENTING:**

1.  **JANGAN PERNAH Memutuskan Hasil Secara Langsung:** Tugas utama Anda adalah mendeskripsikan situasi dan bertanya kepada pemain apa yang ingin mereka lakukan. Untuk setiap tindakan di mana hasilnya tidak pasti (menyerang, membujuk, menyelinap, menyelidiki, memanjat, dll.), Anda **HARUS** meminta pemain untuk melakukan lemparan dadu yang spesifik, biasanya **d20**.
2.  **Minta Lemparan Spesifik:** Beri tahu pemain dengan tepat apa yang harus dilempar. Contoh:
    *   "Baiklah, lakukan lemparan **d20** untuk pemeriksaan Dexterity (Stealth) untuk melihat apakah kamu bisa menyelinap lewat."
    *   "Dia tampak skeptis. Lakukan lemparan **d20** untuk pemeriksaan Charisma (Persuasion)."
    *   "Goblin itu menyerang! Lakukan lemparan **d20** untuk serangan jarak dekat."
    *   "Kamu harus melakukan lemparan **d20** untuk pemeriksaan Strength (Athletics) DC 15 untuk memanjat tebing itu."
3.  **Interpretasikan Hasil Lemparan:** Setelah pemain memberikan hasil lemparannya, narasikan hasilnya.
    *   Lemparan **1** adalah **Kegagalan Kritis**. Sesuatu yang sangat buruk atau lucu terjadi.
    *   Lemparan **20** pada d20 adalah **Keberhasilan Kritis** (untuk serangan dan lemparan penyelamatan). Karakter berhasil dengan spektakuler.
    *   Untuk pemeriksaan melawan DC, lemparan yang sama atau lebih tinggi dari DC adalah keberhasilan. Lemparan yang lebih rendah adalah kegagalan. Deskripsikan tingkat keberhasilan atau kegagalan.
4.  **Perolehan Item:** Ketika seorang karakter mendapatkan item baru, Anda HARUS memformatnya dalam respons Anda seperti ini: **ITEM:[Nama Item] (Tag: [Tag])**. Contoh: "Kamu menemukan ramuan penyembuh, ITEM:Potion of Healing (Tag: Habis Pakai)."
5.  **Mode Tempur - SANGAT PENTING:**
    *   **Memulai Pertempuran:** Saat pertempuran dimulai, Anda HARUS memulai respons Anda dengan tag \`COMBAT_START:[Lebar]x[Tinggi]\`. Contoh: \`COMBAT_START:10x10\`. Ini mengaktifkan peta taktis.
    *   **Menempatkan Unit:** Segera setelah memulai pertempuran, tempatkan semua karakter dan musuh di peta menggunakan tag pembaruan.
    *   **Memperbarui Posisi:** Setiap kali karakter atau musuh bergerak atau bertindak yang mengubah situasi taktis, Anda HARUS menyertakan tag \`COMBAT_UPDATE:[NamaUnit1]@([X],[Y]),[NamaUnit2]@([X],[Y])\`. Contoh: \`COMBAT_UPDATE:Goblin 1@(3,4),${mainCharacter.name}@ (5,5)\`.
        - Pojok kiri atas adalah (1,1).
        - Pastikan nama unit konsisten. Untuk musuh, gunakan nama seperti "Goblin 1", "Goblin 2", "Ogre".
        - Anda dapat memperbarui beberapa unit dalam satu tag.
    *   **Mengakhiri Pertempuran:** Saat pertempuran selesai (semua musuh dikalahkan atau melarikan diri), Anda HARUS memulai respons Anda dengan tag \`COMBAT_END\`. Ini menonaktifkan peta.
6.  **Fokus Narasi:** Selalu narasikan dari sudut pandang Karakter Utama, ${mainCharacter.name}. Sapa mereka sebagai "Anda" atau "Kamu". Anggota party lainnya adalah Rekan yang Anda kendalikan.
7.  **Informasi Party:**
    - **Karakter Utama:** ${mainCharacter.name} (${mainCharacter.race} ${mainCharacter.characterClass}).
      - Penampilan: ${mainCharacter.generated.characterDescription}
      - Statistik: Kekuatan ${mainCharacter.stats.strength}, Kelincahan ${mainCharacter.stats.dexterity}, Konstitusi ${mainCharacter.stats.constitution}, Kecerdasan ${mainCharacter.stats.intelligence}, Kebijaksanaan ${mainCharacter.stats.wisdom}, Karisma ${mainCharacter.stats.charisma}
      - Latar Belakang: ${mainCharacter.backgroundStory}
    - **Rekan:** ${otherCharacters.length > 0 ? otherCharacters.map(c => `${c.name} (${c.race} ${c.characterClass})`).join(', ') : 'Tidak ada'}.
    - **Ukuran Party:** ${party.length} (Maks 5).
8.  **Sistem Satuan:** Gunakan unit metrik (meter, kilogram) untuk deskripsi. Peta taktis merepresentasikan ini secara visual.
9.  **Bahasa untuk Nama:** Nama lokasi (contoh: Phandalin), nama orang (Gundren Rockseeker), dan nama item harus tetap dalam Bahasa Inggris. Jangan menerjemahkannya untuk menjaga nuansa fantasi.
10. **Perkenalkan Rekan:** Untuk menawarkan rekan baru, pertama deskripsikan karakter dan buat mereka mengajukan tawaran secara percakapan. Kemudian, Anda **HARUS** menempatkan tag persis ini di baris baru setelahnya: \`INVITE_CHARACTER:[Nama],[Ras],[Kelas],[Gender]\`. Tag ini memicu tombol interaktif. Lakukan ini hanya jika party memiliki kurang dari 5 anggota. Contoh: Kurcaci itu menggumam, "Aku juga menuju ke gua-gua itu. Lebih aman bepergian bersama. Boleh aku bergabung?"\nINVITE_CHARACTER:Boric,Dwarf,Fighter,Male`
    };

    const campaigns = {
        'lost-mine-of-phandelver': {
            en: `You are a master Dungeon Master running the "Lost Mine of Phandelver" campaign for Dungeons & Dragons 5th Edition for a solo player.

**CAMPAIGN PREMISE:**
The story begins on the Triboar Trail. The player's party has been hired by a dwarf named Gundren Rockseeker to escort a wagon of supplies to the rough-and-tumble frontier town of Phandalin. The journey is about 50 miles and takes a few days. The pay is 10 gold pieces each. You will start the adventure with the party traveling on the road, a couple of days out from Phandalin.

${commonRules.en}

Now, begin the adventure. Describe the scene on the Triboar Trail, with the party escorting the wagon. End your first message by setting up the first encounter (the goblin ambush with the dead horses) and ask the Main Character, "What do you do?". Do not ask the player to confirm, just start the story.`,
            id: `Anda adalah seorang Dungeon Master (DM) ahli yang menjalankan kampanye "Lost Mine of Phandelver" untuk Dungeons & Dragons Edisi ke-5 bagi pemain solo.

**PREMIS KAMPANYE:**
Cerita dimulai di Jalan Triboar. Party pemain telah disewa oleh seorang kurcaci bernama Gundren Rockseeker untuk mengawal gerobak pasokan ke kota perbatasan yang liar, Phandalin. Perjalanan ini sekitar 80 kilometer dan memakan waktu beberapa hari. Bayarannya adalah 10 keping emas untuk setiap orang. Anda akan memulai petualangan dengan party yang sedang melakukan perjalanan di jalan, beberapa hari sebelum mencapai Phandalin.

${commonRules.id}

Sekarang, mulailah petualangan. Deskripsikan adegan di Jalan Triboar, dengan party yang mengawal gerobak. Akhiri pesan pertama Anda dengan menyiapkan pertemuan pertama (penyergapan goblin dengan kuda-kuda mati) dan tanyakan pada Karakter Utama, "Apa yang kamu lakukan?". Jangan meminta konfirmasi pemain, langsung mulai ceritanya.`
        },
        'frozen-sick': {
            en: `You are a master Dungeon Master running the "Frozen Sick" adventure for Dungeons & Dragons 5th Edition for a solo player.

**CAMPAIGN PREMISE:**
The story begins in Palebank Village, a remote fishing outpost in the icy land of the Greying Wildlands. A mysterious illness called the "Frigid Woe" is spreading, causing sufferers to develop blue veins and become cold to the touch, though it's not immediately lethal. The party is hired to travel to the frozen island of Eiselcross to find the source of the plague and hopefully a cure.

${commonRules.en}

Now, begin the adventure. The party is gathered inside the "Jolly Dwarf" tavern in Palebank Village. Describe the cozy tavern, the chilling wind outside, and the worried looks on the faces of the locals. An important figure, Urgon Wenth, approaches their table with a proposition. Describe his appearance and begin the dialogue. End your first message by having Urgon ask the Main Character, "I hear you're looking for work. Might you be interested in a job that's vital to this community's survival? What do you say?". Do not ask the player to confirm, just start the story.`,
            id: `Anda adalah seorang Dungeon Master (DM) ahli yang menjalankan petualangan "Frozen Sick" untuk Dungeons & Dragons Edisi ke-5 bagi pemain solo.

**PREMIS KAMPANYE:**
Cerita dimulai di Desa Palebank, sebuah pos pemancingan terpencil di tanah es Greying Wildlands. Penyakit misterius yang disebut "Frigid Woe" (Penyakit Beku) menyebar, menyebabkan penderitanya mengalami urat biru dan menjadi dingin saat disentuh, meskipun tidak langsung mematikan. Party disewa untuk melakukan perjalanan ke pulau beku Eiselcross untuk menemukan sumber wabah dan semoga obatnya.

${commonRules.id}

Sekarang, mulailah petualangan. Party berkumpul di dalam kedai "Jolly Dwarf" di Desa Palebank. Deskripsikan kedai yang nyaman, angin dingin di luar, dan raut khawatir di wajah penduduk setempat. Seorang tokoh penting, Urgon Wenth, mendekati meja mereka dengan sebuah tawaran. Deskripsikan penampilannya dan mulailah dialog. Akhiri pesan pertama Anda dengan Urgon bertanya kepada Karakter Utama, "Saya dengar Anda sedang mencari pekerjaan. Mungkin Anda tertarik dengan pekerjaan yang sangat penting bagi kelangsungan hidup komunitas ini? Bagaimana?". Jangan meminta konfirmasi pemain, langsung mulai ceritanya.`
        }
    };
    return campaigns[campaign][lang];
}

export const createStoryChat = (party: FinalCharacter[], mainCharacterIndex: number, lang: 'en' | 'id', campaign: Campaign, initialHistory?: StoryEvent[]): Chat => {
    const systemInstruction = getSystemInstruction(campaign, party, mainCharacterIndex, lang);

    const mappedHistory: Content[] = (initialHistory || [])
        .filter(event => event.type === 'dm' || event.type === 'player' || event.type === 'game-event')
        .map(event => {
            const role = (event.type === 'player') ? 'user' : 'model';
            return {
                role,
                parts: [{ text: event.text }]
            };
        });

    const chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction: systemInstruction,
        },
        history: mappedHistory
    });
    return chat;
};

export const generateCharacterName = async (options: { race: string, characterClass: string, gender: string }, lang: 'en' | 'id'): Promise<string> => {
    const prompts = {
        en: `Generate a single, fitting, and cool-sounding fantasy name for a Dungeons & Dragons character.
    - Race: ${options.race}
    - Class: ${options.characterClass}
    - Gender: ${options.gender}
    Do not provide any explanation, just the name itself. For example: "Kaelen Shadowsun" or "Grizelda Ironhand".`,
        id: `Hasilkan satu nama fantasi yang cocok dan terdengar keren untuk karakter Dungeons & Dragons.
    - Ras: ${options.race}
    - Kelas: ${options.characterClass}
    - Gender: ${options.gender}
    Jangan berikan penjelasan apa pun, cukup namanya saja. Contoh: "Kaelen Shadowsun" atau "Grizelda Ironhand".`
    }

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompts[lang],
        });
        return response.text.trim().replace(/"/g, ''); // Clean up potential quotes
    } catch (error) {
        console.error("Error generating character name:", error);
        return lang === 'en' ? `Mysterious ${options.race}` : `Ras ${options.race} Misterius`;
    }
};

export const generateBackgroundStory = async (options: CharacterOptions, lang: 'en' | 'id'): Promise<string> => {
  const prompts = {
      en: `
    Create a brief, compelling Dungeons & Dragons 5e background story (2-3 paragraphs) for the following character. Write it in English.
    - Race: ${options.race}
    - Class: ${options.characterClass}
    - Background: ${options.background}
    - Alignment: ${options.alignment}
    - Key Personality Trait: Base the story on their highest and lowest ability scores (Str: ${options.stats.strength}, Dex: ${options.stats.dexterity}, Con: ${options.stats.constitution}, Int: ${options.stats.intelligence}, Wis: ${options.stats.wisdom}, Cha: ${options.stats.charisma}).
    The story should be evocative and give them a clear motivation for adventuring. Do not include a name.
  `,
      id: `
    Buat cerita latar belakang Dungeons & Dragons 5e yang singkat dan menarik (2-3 paragraf) untuk karakter berikut. Tulis dalam Bahasa Indonesia.
    - Ras: ${options.race}
    - Kelas: ${options.characterClass}
    - Latar Belakang: ${options.background}
    - Alignment: ${options.alignment}
    - Ciri Kepribadian Utama: Dasarkan cerita pada skor kemampuan tertinggi dan terendah mereka (Kekuatan: ${options.stats.strength}, Kelincahan: ${options.stats.dexterity}, Konstitusi: ${options.stats.constitution}, Kecerdasan: ${options.stats.intelligence}, Kebijaksanaan: ${options.stats.wisdom}, Karisma: ${options.stats.charisma}).
    Cerita harus menggugah dan memberi mereka motivasi yang jelas untuk berpetualang. Jangan sertakan nama.
  `
  };
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompts[lang],
    });
    return response.text.trim();
  } catch (error) {
    console.error("Error generating background story:", error);
    throw new Error("Failed to generate background story from AI.");
  }
};


export const generateCharacterDetails = async (
  options: CharacterOptions, lang: 'en' | 'id'
): Promise<GeneratedData> => {
  try {
    const prompt = lang === 'en' ? `
      Based on a Dungeons & Dragons 5e character with the following detailed attributes, generate a rich character profile in English.
      
      USER-PROVIDED DETAILS:
      - Name: ${options.name || 'Unnamed'}
      - Race: ${options.race}
      - Class: ${options.characterClass}
      - Background: ${options.background}
      - Alignment: ${options.alignment}
      - Gender: ${options.gender}
      - Appearance: ${getHeightDescription(options.height, 'en')}, ${getBuildDescription(options.build, 'en')}, ${getMuscularityDescription(options.muscularity, 'en')}. ${options.hairType} hair with color ${options.hairColor}. Primary clothing color theme is ${options.clothColor}.
      - Core Stats: Strength ${options.stats.strength}, Dexterity ${options.stats.dexterity}, Constitution ${options.stats.constitution}, Intelligence ${options.stats.intelligence}, Wisdom ${options.stats.wisdom}, Charisma ${options.stats.charisma}.
      - Preferences: Favors fighting in ${options.favoriteTerrain} terrain against ${options.favoriteEnemy}.
      - Fighting Style: ${options.fightingStyle}
      - Selected Skill Proficiencies: ${options.selectedSkills.join(', ') || 'None specified'}
      - Custom Backstory: ${options.backgroundStory || 'None provided. Please create one based on their race, class, and background.'}
      - Custom Special Move: ${options.customSpecialMove || 'None provided. Please create one.'}

      GENERATE THE FOLLOWING JSON:
      1.  **characterDescription**: A brief, evocative paragraph describing the character's personality, demeanor, and appearance based on all the details provided.
      2.  **startingItems**: A thematic list of starting equipment. Include standard class/background gear and one or two unique, flavorful items. A character should have at least one weapon and one piece of armor/shield.
      3.  **skills**: A list of additional flavorful talents, quirks, or non-combat abilities that complement their specified proficiencies.
      4.  **specialMove**: If a custom move was provided, use it. Otherwise, create a cool-sounding, descriptive name and brief explanation for a signature move this character might have.
      5.  **currency**: A starting amount of wealth based on their background (e.g., a Noble would have more than an Urchin).
    ` : `
      Berdasarkan karakter Dungeons & Dragons 5e dengan atribut terperinci berikut, hasilkan profil karakter yang kaya dalam Bahasa Indonesia.
      
      DETAIL DARI PENGGUNA:
      - Nama: ${options.name || 'Tanpa Nama'}
      - Ras: ${options.race}
      - Kelas: ${options.characterClass}
      - Latar Belakang: ${options.background}
      - Alignment: ${options.alignment}
      - Gender: ${options.gender}
      - Penampilan: ${getHeightDescription(options.height, 'id')}, ${getBuildDescription(options.build, 'id')}, ${getMuscularityDescription(options.muscularity, 'id')}. Rambut ${options.hairType} dengan warna ${options.hairColor}. Tema warna pakaian utama adalah ${options.clothColor}.
      - Statistik Inti: Kekuatan ${options.stats.strength}, Kelincahan ${options.stats.dexterity}, Konstitusi ${options.stats.constitution}, Kecerdasan ${options.stats.intelligence}, Kebijaksanaan ${options.stats.wisdom}, Karisma: ${options.stats.charisma}.
      - Preferensi: Suka bertarung di medan ${options.favoriteTerrain} melawan ${options.favoriteEnemy}.
      - Gaya Bertarung: ${options.fightingStyle}
      - Kemahiran Keterampilan yang Dipilih: ${options.selectedSkills.join(', ') || 'Tidak ditentukan'}
      - Latar Belakang Kustom: ${options.backgroundStory || 'Tidak ada. Tolong buatkan satu berdasarkan ras, kelas, dan latar belakang mereka.'}
      - Jurus Spesial Kustom: ${options.customSpecialMove || 'Tidak ada. Tolong buatkan satu.'}

      PENTING: Untuk 'startingItems' dan 'specialMove', berikan nama dalam Bahasa Inggris. Deskripsi lainnya dalam Bahasa Indonesia.

      HASILKAN JSON BERIKUT:
      1.  **characterDescription**: Paragraf singkat yang menggugah yang menggambarkan kepribadian, sikap, dan penampilan karakter berdasarkan semua detail yang diberikan. (dalam Bahasa Indonesia)
      2.  **startingItems**: Daftar tematik perlengkapan awal. Sertakan perlengkapan standar kelas/latar belakang dan satu atau dua item unik. Karakter harus memiliki setidaknya satu senjata dan satu zirah/perisai. (dalam Bahasa Inggris)
      3.  **skills**: Daftar bakat, keunikan, atau kemampuan non-tempur tambahan yang melengkapi kemahiran yang ditentukan. (dalam Bahasa Indonesia)
      4.  **specialMove**: Jika jurus kustom diberikan, gunakan itu. Jika tidak, buat nama deskriptif yang terdengar keren dan penjelasan singkat untuk jurus khas yang mungkin dimiliki karakter ini. (dalam Bahasa Inggris)
      5.  **currency**: Jumlah kekayaan awal berdasarkan latar belakang mereka (misalnya, seorang Bangsawan akan memiliki lebih dari seorang Gelandangan).
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            characterDescription: { type: Type.STRING },
            startingItems: { type: Type.ARRAY, items: { type: Type.STRING } },
            skills: { type: Type.ARRAY, items: { type: Type.STRING } },
            specialMove: { type: Type.STRING },
            currency: {
                type: Type.OBJECT,
                properties: {
                    gp: { type: Type.NUMBER },
                    sp: { type: Type.NUMBER },
                    cp: { type: Type.NUMBER },
                }
            }
          },
          required: ["characterDescription", "startingItems", "skills", "specialMove", "currency"],
        },
      },
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as GeneratedData;

  } catch (error) {
    console.error("Error generating character details:", error);
    throw new Error("Failed to generate character details from AI.");
  }
};

export const generateCharacterImage = async (options: CharacterOptions, lang: 'en' | 'id'): Promise<string> => {
    const heightDesc = getHeightDescription(options.height, lang);
    const buildDesc = getBuildDescription(options.build, lang);
    const muscularityDesc = getMuscularityDescription(options.muscularity, lang);

    const prompt = `
        High-quality, detailed fantasy digital painting of a D&D character.
        Name: ${options.name || 'A mysterious adventurer'}.
        Gender: ${options.gender}.
        Race: ${options.race}.
        Class: ${options.characterClass}.
        Alignment: ${options.alignment}.
        Fighting Style: ${options.fightingStyle}.
        Physical Appearance: They are ${heightDesc}, ${buildDesc}, and ${muscularityDesc}, with a skin tone of ${options.skinColor}. They have ${options.hairType} hair with the color ${options.hairColor}.
        Clothing: Their clothing and armor prominently feature a ${options.clothColor} color scheme. The character should be visibly equipped with a weapon suitable for their class.
        Style: Dramatic lighting, epic fantasy art, character portrait, detailed armor/clothing appropriate for their class. No text, no watermarks. The overall color palette should complement the character's clothing theme.
    `;

    try {
        const response = await ai.models.generateImages({
            model: 'imagen-3.0-generate-002',
            prompt: prompt,
            config: {
              numberOfImages: 1,
              outputMimeType: 'image/jpeg',
              aspectRatio: '3:4',
            },
        });
        
        if (!response.generatedImages || response.generatedImages.length === 0) {
            throw new Error("No image was generated.");
        }

        const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
        return `data:image/jpeg;base64,${base64ImageBytes}`;

    } catch (error) {
        console.error("Error generating character image:", error);
        throw new Error("Failed to generate character image from AI.");
    }
};
