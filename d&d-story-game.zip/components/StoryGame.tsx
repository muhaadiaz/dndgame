
import React, { useState, useEffect, useRef, useCallback, useLayoutEffect } from 'react';
import { Chat } from '@google/genai';
import { FinalCharacter, StoryEvent, InventoryItem, Campaign, CharacterOptions, Invitation } from '../types';
import { createStoryChat } from '../services/geminiService';
import DiceRoller from './DiceRoller';
import { useLocalization } from '../contexts/LocalizationContext';
import { createFinalCharacter, getRandomElement, generateRandomStats, getRandomSkills } from '../utils';
import { BACKGROUNDS, ALIGNMENTS, HAIR_TYPES, HAIR_COLORS, SKIN_COLORS, CLOTH_THEMES, TERRAINS, ENEMIES, FIGHTING_STYLES, SKILLS, MAX_CHARACTERS } from '../constants';
import Minimap from './Minimap';


interface StoryGameProps {
  characters: FinalCharacter[];
  setCharacters: React.Dispatch<React.SetStateAction<FinalCharacter[]>>;
  activeCharacterIndex: number;
  onCharacterChange: (index: number) => void;
  mainCharacterIndex: number;
  lang: 'en' | 'id';
  campaign: Campaign;
  storyLog: StoryEvent[];
  setStoryLog: React.Dispatch<React.SetStateAction<StoryEvent[]>>;
  onSaveGame: () => void;
  onExitStory: () => void;
}

const LOG_CHUNK_SIZE = 15;

const LoadingSpinner: React.FC = () => (
    <svg className="animate-spin h-5 w-5 text-accent-light" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
);

const INVITE_REGEX = /INVITE_CHARACTER:\s*\[?([^,]+),([^,]+),([^,]+),([^,]+)\s*\]?/g;
const COMBAT_START_REGEX = /COMBAT_START:\s*(\d+)x(\d+)/g;
const COMBAT_UPDATE_REGEX = /COMBAT_UPDATE:(.+)/g;
const COMBAT_END_REGEX = /COMBAT_END/g;

const StoryGame: React.FC<StoryGameProps> = ({ characters, setCharacters, activeCharacterIndex, onCharacterChange, mainCharacterIndex, lang, campaign, storyLog, setStoryLog, onSaveGame, onExitStory }) => {
    const { t } = useLocalization();
    const [chat, setChat] = useState<Chat | null>(null);
    const [playerInput, setPlayerInput] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [isExitModalOpen, setIsExitModalOpen] = useState(false);
    const [activeTab, setActiveTab] = useState<'story' | 'roller'>('story');
    const storyContainerRef = useRef<HTMLDivElement>(null);
    const storyEndRef = useRef<HTMLDivElement>(null);
    const prevScrollHeight = useRef<number | null>(null);
    const [displayCount, setDisplayCount] = useState(LOG_CHUNK_SIZE);

    const [isInCombat, setIsInCombat] = useState(false);
    const [isMinimapVisible, setIsMinimapVisible] = useState(true);
    const [gridSize, setGridSize] = useState<{ width: number; height: number } | null>(null);
    const [tokenPositions, setTokenPositions] = useState<{ [name: string]: { x: number; y: number } }>({});

    const activeCharacter = characters[activeCharacterIndex];

    const handleCharacterUpdate = useCallback((updates: Partial<FinalCharacter>) => {
        setCharacters(prevChars =>
            prevChars.map((char, index) =>
                index === activeCharacterIndex ? { ...char, ...updates } : char
            )
        );
    }, [activeCharacterIndex, setCharacters]);
    
    const handleItemUpdateForCharacter = useCallback((charIndex: number, newItems: InventoryItem[]) => {
        setCharacters(prevChars => {
            const charToUpdate = prevChars[charIndex];
            if (!charToUpdate) return prevChars;
    
            const updatedInventory = [...charToUpdate.inventory, ...newItems];
            return prevChars.map((char, index) => 
                index === charIndex ? { ...char, inventory: updatedInventory } : char
            );
        });
    }, [setCharacters]);

    const processAndLogDMResponse = useCallback(async (
        dmResponsePromise: Promise<{ text: string }>,
        characterIndexToUpdate: number
    ) => {
        try {
            const response = await dmResponsePromise;
            let storyText = response.text;
            let parsedInvitation: Invitation | null = null;
            
            const newItems: InventoryItem[] = [];
            const currencyToAdd = { gp: 0, sp: 0, cp: 0 };
            const goldRegex = /(\d+)\s*(?:GP|Gold Coins?|Koin Emas)/i;
            const silverRegex = /(\d+)\s*(?:SP|Silver Coins?|Koin Perak)/i;
            const copperRegex = /(\d+)\s*(?:CP|Copper Coins?|Koin Tembaga)/i;
            const ITEM_REGEX_CAPTURE = /ITEM:(.+?)\s*\((?:Tag|tag):\s*([^)]+)\)/gi;

            storyText = storyText.replace(COMBAT_START_REGEX, (match, width, height) => {
                const newGridSize = { width: parseInt(width), height: parseInt(height) };
                setIsInCombat(true);
                setIsMinimapVisible(true);
                setGridSize(newGridSize);
                setTokenPositions({});
                setStoryLog(prev => [...prev, { type: 'game-event', text: t('combatModeActive') }]);
                return '';
            });

            storyText = storyText.replace(COMBAT_END_REGEX, () => {
                setIsInCombat(false);
                setIsMinimapVisible(false);
                setStoryLog(prev => [...prev, { type: 'game-event', text: t('combatEnded') }]);
                return '';
            });

            storyText = storyText.replace(COMBAT_UPDATE_REGEX, (match, updates) => {
                setTokenPositions(currentPositions => {
                    const newPositions = { ...currentPositions };
                    const units = updates.split(',');
                    units.forEach((unit: string) => {
                        const parts = unit.match(/([^@]+)@\s*\((\d+),(\d+)\)/);
                        if (parts) {
                            const name = parts[1].trim();
                            const x = parseInt(parts[2], 10);
                            const y = parseInt(parts[3], 10);
                            if (!isNaN(x) && !isNaN(y)) {
                                newPositions[name] = { x, y };
                            }
                        }
                    });
                    return newPositions;
                });
                return '';
            });

            storyText = storyText.replace(ITEM_REGEX_CAPTURE, (match, name, tagContent) => {
                const itemName = name.trim().replace(/[\[\]]/g, '');
                const tag = tagContent.trim();
                
                const parseCurrency = (text: string) => {
                    const goldMatch = text.match(goldRegex);
                    if (goldMatch) currencyToAdd.gp += parseInt(goldMatch[1], 10);
                    
                    const silverMatch = text.match(silverRegex);
                    if (silverMatch) currencyToAdd.sp += parseInt(silverMatch[1], 10);

                    const copperMatch = text.match(copperRegex);
                    if (copperMatch) currencyToAdd.cp += parseInt(copperMatch[1], 10);
                };

                parseCurrency(tag);
                parseCurrency(itemName);

                newItems.push({ name: itemName, tag: tag });
                return itemName;
            });
            
            if (newItems.length > 0) {
                handleItemUpdateForCharacter(characterIndexToUpdate, newItems);
                const itemNames = newItems.map(i => i.name).join(', ');
                setStoryLog(prev => [...prev, { type: 'game-event', text: `${t('youAcquired')}: ${itemNames}` }]);
            }
            
            if (currencyToAdd.gp > 0 || currencyToAdd.sp > 0 || currencyToAdd.cp > 0) {
                setCharacters(prevChars => {
                    return prevChars.map((char, index) => {
                        if (index === characterIndexToUpdate) {
                            return {
                                ...char,
                                currency: {
                                    gp: char.currency.gp + currencyToAdd.gp,
                                    sp: char.currency.sp + currencyToAdd.sp,
                                    cp: char.currency.cp + currencyToAdd.cp,
                                }
                            };
                        }
                        return char;
                    });
                });
                let currencyMessageParts: string[] = [];
                if (currencyToAdd.gp > 0) currencyMessageParts.push(`${currencyToAdd.gp} GP`);
                if (currencyToAdd.sp > 0) currencyMessageParts.push(`${currencyToAdd.sp} SP`);
                if (currencyToAdd.cp > 0) currencyMessageParts.push(`${currencyToAdd.cp} CP`);
                setStoryLog(prev => [...prev, { type: 'game-event', text: `${t('youAcquired')}: ${currencyMessageParts.join(', ')}` }]);
            }
    
            storyText = storyText.replace(INVITE_REGEX, (match, name, race, characterClass, gender) => {
                if (characters.length < MAX_CHARACTERS) {
                    parsedInvitation = { 
                        name: name.trim(), 
                        race: race.trim(), 
                        characterClass: characterClass.trim(), 
                        gender: gender.trim(), 
                        status: 'pending' 
                    };
                } else {
                    setStoryLog(prev => [...prev, { type: 'system', text: t('partyFull') }]);
                }
                return ''; 
            });
    
            storyText = storyText.trim();
            if (storyText || parsedInvitation) {
                 setStoryLog(prev => [...prev, { 
                     type: 'dm', 
                     text: storyText, 
                     invitation: parsedInvitation || undefined 
                }]);
            }
    
        } catch (error) {
            console.error("Error processing DM response:", error);
            setStoryLog(prev => [...prev, { type: 'system', text: t('errorDMConnectionLost') }]);
        }
    }, [handleItemUpdateForCharacter, setStoryLog, t, characters.length, setCharacters]);

    useEffect(() => {
        // Only autoscroll if a new message was added, not when history is revealed
        if (prevScrollHeight.current === null) {
            storyEndRef.current?.scrollIntoView({ behavior: "smooth" });
        }
    }, [storyLog]);

    useLayoutEffect(() => {
        // This effect preserves scroll position when loading more history
        if (prevScrollHeight.current !== null && storyContainerRef.current) {
            const newScrollHeight = storyContainerRef.current.scrollHeight;
            storyContainerRef.current.scrollTop = newScrollHeight - prevScrollHeight.current;
            prevScrollHeight.current = null; // Reset after use
        }
    }, [displayCount]);

    const handleShowMore = () => {
        if (storyContainerRef.current) {
            prevScrollHeight.current = storyContainerRef.current.scrollHeight;
        }
        setDisplayCount(prev => prev + LOG_CHUNK_SIZE);
    };

    const visibleStoryLog = storyLog.slice(Math.max(0, storyLog.length - displayCount));
    const hasMoreLogs = storyLog.length > displayCount;

    useEffect(() => {
        const initializeAdventure = async () => {
            setIsLoading(true);
            if (characters.length === 0 || mainCharacterIndex === null) return;
            
            const chatSession = createStoryChat(characters, mainCharacterIndex, lang, campaign, storyLog);
            setChat(chatSession);
    
            if (storyLog.length === 0) {
                setStoryLog(prev => [...prev, { type: 'system', text: t('dmIsSettingTheScene') }]);
                await processAndLogDMResponse(chatSession.sendMessage({ message: t('begin') }), mainCharacterIndex);
            }
            
            setIsLoading(false);
        };
        initializeAdventure();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [mainCharacterIndex, lang, campaign]);
    
    const handlePlayerAction = useCallback(async (actionText: string) => {
        if (!actionText.trim() || isLoading || !chat) return;
        
        setIsLoading(true);
        setStoryLog(prev => [...prev, { type: 'player', text: actionText }]);
    
        await processAndLogDMResponse(chat.sendMessage({ message: actionText }), activeCharacterIndex);
        
        setIsLoading(false);
    }, [isLoading, chat, processAndLogDMResponse, activeCharacterIndex, setStoryLog]);

    const updateInvitationStatus = useCallback((eventIndex: number, newStatus: Invitation['status']) => {
        setStoryLog(prev => {
            const newLog = [...prev];
            const eventToUpdate = newLog[eventIndex];
            if (eventToUpdate && eventToUpdate.invitation) {
                newLog[eventIndex] = {
                    ...eventToUpdate,
                    invitation: { ...eventToUpdate.invitation, status: newStatus }
                };
            }
            return newLog;
        });
    }, [setStoryLog]);

    const handleAcceptInvite = useCallback(async (eventIndex: number, invite: Invitation) => {
        if (!invite) return;
        updateInvitationStatus(eventIndex, 'generating');
        
        try {
            const randomOptions: CharacterOptions = {
              name: invite.name, 
              race: invite.race,
              characterClass: invite.characterClass,
              gender: invite.gender,
              background: getRandomElement(BACKGROUNDS),
              alignment: getRandomElement(ALIGNMENTS),
              hairType: getRandomElement(HAIR_TYPES),
              hairColor: getRandomElement(HAIR_COLORS),
              skinColor: getRandomElement(SKIN_COLORS),
              clothColor: getRandomElement(CLOTH_THEMES).name,
              height: Math.floor(Math.random() * 101),
              build: Math.floor(Math.random() * 101),
              muscularity: Math.floor(Math.random() * 101),
              favoriteTerrain: getRandomElement(TERRAINS),
              favoriteEnemy: getRandomElement(ENEMIES),
              stats: generateRandomStats(),
              backgroundStory: '', 
              selectedSkills: getRandomSkills(SKILLS, 4),
              fightingStyle: getRandomElement(FIGHTING_STYLES),
              customSpecialMove: '',
            };

            const newCharacter = await createFinalCharacter(randomOptions, lang, t);
            setCharacters(prev => [...prev, newCharacter]);
            updateInvitationStatus(eventIndex, 'accepted');
            
            const playerResponseToAI = `(I have accepted. ${newCharacter.name} joins the party.)`;
            await handlePlayerAction(playerResponseToAI);

        } catch (error) {
            console.error("Error generating invited character:", error);
            updateInvitationStatus(eventIndex, 'error');
        }
    }, [updateInvitationStatus, lang, t, setCharacters, handlePlayerAction]);

    const handleDeclineInvite = useCallback(async (eventIndex: number, invite: Invitation) => {
        if (!invite) return;
        updateInvitationStatus(eventIndex, 'declined');
        const playerResponseToAI = `(I have declined the invitation for ${invite.name} to join.)`;
        await handlePlayerAction(playerResponseToAI);
    }, [updateInvitationStatus, handlePlayerAction]);


    const handleFormSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        handlePlayerAction(playerInput);
        setPlayerInput('');
    };
    
    const handleRollResult = (resultText: string) => {
        setPlayerInput(prev => `(${t('myRoll')}: ${resultText}) ${prev}`);
        setActiveTab('story');
    };

    const handleCharacterSwap = (index: number) => {
        if (index === activeCharacterIndex || isLoading) return;
        onCharacterChange(index);
    };

    const getLogEntryStyle = (type: StoryEvent['type']) => {
        switch (type) {
            case 'dm':
                return 'bg-black/10 border-l-4 border-accent/30 p-4 rounded-lg text-text-main italic';
            case 'player':
                return 'bg-black/30 border-r-4 border-accent-light p-4 rounded-lg text-accent-light/90 text-right';
            case 'system':
                return 'text-center text-text-muted font-bold tracking-wider py-2';
            case 'game-event':
                 return 'bg-accent/10 border-2 border-dashed border-accent/30 text-accent-light font-bold text-center p-3 rounded-lg';
            default:
                return '';
        }
    };
    
    const renderInvitation = (invitation: Invitation, eventIndex: number) => {
        switch (invitation.status) {
            case 'pending':
                return (
                    <div className="flex flex-col sm:flex-row items-center justify-end gap-3 text-right">
                        <p className="text-text-main font-semibold flex-grow text-left sm:text-right italic">
                            {t('inviteToPartyQuestion', { name: invitation.name })}
                        </p>
                        <button
                            onClick={() => handleDeclineInvite(eventIndex, invitation)}
                            disabled={isLoading}
                            className="bg-black/20 border border-accent/20 text-text-main font-bold py-2 px-6 rounded-lg hover:bg-black/40 transition-all duration-300 w-full sm:w-auto disabled:opacity-50"
                        >
                            {t('decline')}
                        </button>
                        <button
                            onClick={() => handleAcceptInvite(eventIndex, invitation)}
                             disabled={isLoading}
                            className="bg-gradient-to-br from-accent to-accent-dark text-text-on-accent font-bold py-2 px-6 rounded-lg hover:from-accent-dark hover:to-accent-dark transition-all duration-300 w-full sm:w-auto disabled:opacity-50"
                        >
                            {t('addToParty')}
                        </button>
                    </div>
                );
            case 'generating':
                return (
                    <div className="flex items-center justify-end gap-3 text-accent-light italic">
                        <LoadingSpinner />
                        {t('generatingCharacter')}
                    </div>
                );
            case 'accepted':
                return (
                    <p className="text-center font-bold text-green-400">
                        {t('characterJoined', { name: invitation.name })}
                    </p>
                );
            case 'declined':
                return (
                    <p className="text-center font-bold text-text-muted italic">
                        {t('inviteDeclinedMessage', { name: invitation.name })}
                    </p>
                );
            case 'error':
                 return (
                    <p className="text-center font-bold text-red-400">
                        {t('inviteErrorMessage')}
                    </p>
                 );
            default:
                return null;
        }
    };

    return (
        <div className="bg-black/20 backdrop-blur-lg border border-accent/30 p-4 sm:p-6 rounded-xl shadow-2xl mx-auto animate-fade-in max-w-7xl w-full flex flex-col">
            <div className="sm:hidden mb-4 flex-shrink-0">
                <div className="flex border-b-2 border-accent/20">
                    <button onClick={() => setActiveTab('story')} className={`px-4 py-2 font-bold transition-colors ${activeTab === 'story' ? 'text-accent-light border-b-2 border-accent' : 'text-text-muted'}`}>{t('adventure')}</button>
                    <button onClick={() => setActiveTab('roller')} className={`px-4 py-2 font-bold transition-colors ${activeTab === 'roller' ? 'text-accent-light border-b-2 border-accent' : 'text-text-muted'}`}>{t('diceAndCharacter')}</button>
                </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-3 gap-6">
                <div className={`sm:col-span-2 lg:col-span-2 flex flex-col bg-black/20 rounded-lg p-4 ${activeTab === 'story' ? 'flex' : 'hidden sm:flex'}`}>
                    <div ref={storyContainerRef} className="flex-grow space-y-4 pr-2 overflow-y-auto">
                        {hasMoreLogs && (
                            <div className="text-center my-2">
                                <button
                                    onClick={handleShowMore}
                                    className="bg-black/30 hover:bg-black/50 text-accent-light text-sm font-bold py-2 px-4 rounded-full transition-colors"
                                >
                                    {t('showPreviousHistory')}
                                </button>
                            </div>
                        )}
                        {visibleStoryLog.map((entry, index) => (
                           <div key={index} className={`animate-fade-in ${getLogEntryStyle(entry.type)}`}>
                                <p className="whitespace-pre-wrap font-sans">{entry.text}</p>
                                {entry.invitation && (
                                    <div className="mt-4 pt-4 border-t border-dashed border-accent/20">
                                        {renderInvitation(entry.invitation, storyLog.length - visibleStoryLog.length + index)}
                                    </div>
                                )}
                           </div>
                        ))}
                         {isLoading && storyLog.length > 0 && (
                            <div className="flex items-center justify-center gap-3 py-4 text-accent-light italic">
                                <LoadingSpinner />
                                {t('dmIsThinking')}
                            </div>
                         )}
                         <div ref={storyEndRef} />
                    </div>

                    <div className="flex-shrink-0 mt-4 pt-4 border-t border-accent/20">
                        {isInCombat && (
                            <div className="mb-4">
                                <button
                                    onClick={() => setIsMinimapVisible(v => !v)}
                                    className="w-full bg-black/30 hover:bg-black/50 text-accent-light font-bold py-2 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
                                    title={t('showHideMap')}
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M4 6a2 2 0 012-2h12a2 2 0 012 2v12a2 2 0 01-2 2H6a2 2 0 01-2-2V6z" />
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M10 4v16m4-16v16M4 10h16M4 14h16" />
                                    </svg>
                                    {t('minimap')}
                                </button>
                                {isMinimapVisible && gridSize && (
                                    <div className="mt-2 animate-fade-in">
                                        <Minimap
                                            gridSize={gridSize}
                                            tokenPositions={tokenPositions}
                                            characters={characters}
                                        />
                                    </div>
                                )}
                            </div>
                        )}
                        <form onSubmit={handleFormSubmit} className="flex gap-2">
                            <textarea
                                value={playerInput}
                                onChange={e => setPlayerInput(e.target.value)}
                                onKeyDown={e => {
                                    if (e.key === 'Enter' && !e.shiftKey) {
                                        e.preventDefault();
                                        handlePlayerAction(playerInput);
                                        setPlayerInput('');
                                    }
                                }}
                                placeholder={t('whatDoYouDo', { name: activeCharacter.name })}
                                disabled={isLoading}
                                className="flex-grow bg-black/30 border border-accent/20 text-text-main rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-accent/50 resize-none"
                                rows={3}
                            />
                            <button type="submit" disabled={isLoading} className="bg-gradient-to-br from-accent to-accent-dark text-text-on-accent font-bold px-4 rounded-lg hover:from-accent-dark hover:to-accent-dark transition-all duration-300 disabled:from-accent/50 disabled:to-accent-dark/50 disabled:cursor-not-allowed self-stretch">
                                {t('send')}
                            </button>
                        </form>
                    </div>
                </div>
                
                 <div className={`sm:col-span-1 lg:col-span-1 ${activeTab === 'roller' ? 'block' : 'hidden sm:block'} sm:sticky sm:top-6 sm:self-start sm:max-h-[calc(100vh-8rem)] sm:overflow-y-auto`}>
                    <DiceRoller
                        character={activeCharacter}
                        setCharacter={handleCharacterUpdate}
                        onRoll={handleRollResult}
                        characters={characters}
                        activeCharacterIndex={activeCharacterIndex}
                        onCharacterChange={handleCharacterSwap}
                        mainCharacterIndex={mainCharacterIndex}
                    />
                </div>
            </div>
            
            <div className="flex-shrink-0 flex justify-end items-center gap-4 mt-6 pt-4 border-t border-accent/20">
                <button
                    onClick={onSaveGame}
                    className="bg-gradient-to-br from-accent to-accent-dark text-text-on-accent font-bold py-3 px-6 rounded-lg hover:from-accent-dark hover:to-accent-dark transition-all duration-300 shadow-lg"
                >
                    {t('saveGame')}
                </button>
                <button
                    onClick={() => setIsExitModalOpen(true)}
                    className="bg-black/30 border border-stone-600 text-text-main font-bold py-3 px-6 rounded-lg hover:bg-black/50 transition-all duration-300 shadow-lg"
                >
                    {t('exitAdventure')}
                </button>
            </div>

            {isExitModalOpen && (
                <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-end justify-center z-[200] animate-fade-in p-4 pb-12">
                    <div className="bg-black/50 border border-accent/30 rounded-xl shadow-2xl w-full max-w-md p-6 text-center">
                        <h2 className="text-2xl font-bold font-medieval text-text-heading mb-4">{t('exitToMainMenu')}</h2>
                        <p className="text-text-muted mb-6">{t('exitConfirmMessage')}</p>
                        <div className="flex flex-col sm:flex-row gap-4">
                             <button
                                onClick={() => { onSaveGame(); onExitStory(); }}
                                className="w-full bg-gradient-to-br from-accent to-accent-dark text-text-on-accent font-bold py-3 px-4 rounded-lg hover:from-accent-dark hover:to-accent-dark transition-all duration-300"
                            >
                                {t('saveAndExit')}
                            </button>
                            <button
                                onClick={onExitStory}
                                className="w-full bg-black/30 border border-stone-600 text-text-main font-bold py-3 px-4 rounded-lg hover:bg-red-800/50 hover:border-red-600 transition-all"
                            >
                                {t('exitWithoutSaving')}
                            </button>
                        </div>
                        <button onClick={() => setIsExitModalOpen(false)} className="mt-6 text-sm text-text-muted hover:text-white">{t('cancel')}</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default StoryGame;
