import React from 'react';
import { FinalCharacter } from '../types';

interface MinimapProps {
    gridSize: { width: number; height: number };
    tokenPositions: { [name: string]: { x: number; y: number } };
    characters: FinalCharacter[];
}

const getInitials = (name: string): string => {
    if (!name) return '?';
    const nameParts = name.trim().split(' ').filter(Boolean);
    // For "Goblin 1" -> "G1"
    if (nameParts.length > 1) {
      return (nameParts[0][0] + (nameParts[nameParts.length - 1][0] || '')).toUpperCase();
    }
    // For "Hikaroz" -> "HI"
    if (nameParts.length === 1 && nameParts[0].length > 1) {
        return nameParts[0].substring(0, 2).toUpperCase();
    }
    // For single letter names
    if (nameParts.length === 1) {
        return nameParts[0][0].toUpperCase();
    }
    return '?';
};


const Minimap: React.FC<MinimapProps> = ({ gridSize, tokenPositions, characters }) => {
    const characterNames = characters.map(c => c.name);

    return (
        <div className="bg-black/30 p-2 rounded-lg flex justify-center">
            <div
                className="grid border border-accent/20"
                style={{
                    gridTemplateColumns: `repeat(${gridSize.width}, 1.5rem)`, // 24px per cell
                }}
            >
                {[...Array(gridSize.height)].map((_, y) =>
                    [...Array(gridSize.width)].map((_, x) => {
                        const gridX = x + 1;
                        const gridY = y + 1;
                        
                        const tokenEntry = Object.entries(tokenPositions).find(
                            ([_name, pos]) => pos.x === gridX && pos.y === gridY
                        );

                        if (tokenEntry) {
                            const [name] = tokenEntry;
                            const isPlayerCharacter = characterNames.includes(name);
                            const initials = getInitials(name);
                            
                            const style: React.CSSProperties = {
                                width: '100%',
                                height: '100%',
                                borderRadius: '50%',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                fontWeight: 'bold',
                                fontSize: '0.625rem', // 10px
                                lineHeight: '1',
                                border: '2px solid',
                                boxShadow: '0 2px 4px rgba(0,0,0,0.25)',
                                textShadow: '0 1px 1px rgba(0,0,0,0.5)',
                            };

                            if (isPlayerCharacter) {
                                style.backgroundColor = '#f59e0b'; // amber-500
                                style.borderColor = '#b45309'; // amber-700
                                style.color = '#000000';
                            } else {
                                style.backgroundColor = '#dc2626'; // red-600
                                style.borderColor = '#991b1b'; // red-800
                                style.color = '#ffffff';
                            }

                            return (
                                <div key={`${gridX}-${gridY}`} className="border border-accent/20 aspect-square flex items-center justify-center p-0.5" title={name}>
                                    <div style={style}>
                                        {initials}
                                    </div>
                                </div>
                            );
                        }

                        return <div key={`${gridX}-${gridY}`} className="border border-accent/20 aspect-square"></div>;
                    })
                )}
            </div>
        </div>
    );
};

export default Minimap;
