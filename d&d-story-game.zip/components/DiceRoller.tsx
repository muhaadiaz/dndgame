
import React, { useState, useRef, useEffect } from 'react';
import { FinalCharacter, Ability, Currency, InventoryItem } from '../types';
import { getAbilityModifier } from '../utils.ts';
import { ABILITIES } from '../constants';
import { useLocalization } from '../contexts/LocalizationContext';
import CharacterTabs from './CharacterTabs';
import CharacterSheet from './CharacterSheet';

interface DiceRollerProps {
  character: FinalCharacter;
  setCharacter: (updates: Partial<FinalCharacter>) => void;
  onRoll: (resultText: string) => void;
  characters: FinalCharacter[];
  activeCharacterIndex: number;
  onCharacterChange: (index: number) => void;
  mainCharacterIndex: number;
}

type AdvantageState = 'normal' | 'advantage' | 'disadvantage';

const DICE_TYPES = [4, 6, 8, 10, 12, 20];

const EquipModal: React.FC<{
    item: InventoryItem;
    onEquip: (slot: 'weapon' | 'armor') => void;
    onClose: () => void;
    t: (key: string, options?: any) => string;
}> = ({ item, onEquip, onClose, t }) => {
    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-end justify-center z-[100] animate-fade-in p-4 pb-12">
            <div className="bg-black/50 border border-accent/30 rounded-xl shadow-2xl w-full max-w-sm p-6 text-center">
                <h3 className="text-xl font-bold mb-4 text-text-heading">{t('equipAs', { itemName: item.name })}</h3>
                <div className="flex gap-4">
                    <button onClick={() => onEquip('weapon')} className="w-full bg-gradient-to-br from-accent to-accent-dark text-text-on-accent font-bold py-3 px-4 rounded-lg hover:from-accent-dark hover:to-accent-dark transition-all duration-300">
                        {t('equipAsWeapon')}
                    </button>
                    <button onClick={() => onEquip('armor')} className="w-full bg-gradient-to-br from-accent to-accent-dark text-text-on-accent font-bold py-3 px-4 rounded-lg hover:from-accent-dark hover:to-accent-dark transition-all duration-300">
                        {t('equipAsArmor')}
                    </button>
                </div>
                <button onClick={onClose} className="mt-4 text-sm text-text-muted hover:text-white">{t('cancel')}</button>
            </div>
        </div>
    );
};

const DetailsModal: React.FC<{
    character: FinalCharacter;
    onClose: () => void;
    t: (key: string) => string;
}> = ({ character, onClose, t }) => {
    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-end justify-center z-[110] animate-fade-in p-4">
            <div className="relative bg-transparent w-full max-w-6xl h-[90vh] flex flex-col">
                 <CharacterSheet character={character} onEdit={()=>{}} onStartStory={()=>{}} isModalView={true} />
                <button 
                    onClick={onClose} 
                    className="absolute top-4 right-4 bg-black/50 text-white rounded-full w-8 h-8 flex items-center justify-center hover:bg-red-600 transition-colors text-2xl z-10"
                    aria-label={t('close')}
                >
                    &times;
                </button>
            </div>
        </div>
    );
};


export default function DiceRoller({
    character, setCharacter, onRoll,
    characters, activeCharacterIndex, onCharacterChange, mainCharacterIndex
}: DiceRollerProps) {
    const { t } = useLocalization();
    const [lastRoll, setLastRoll] = useState<string | null>(null);
    const [selectedDie, setSelectedDie] = useState<number | null>(20);
    const [selectedAbilityModifier, setSelectedAbilityModifier] = useState<Ability | null>(null);
    const [advantageState, setAdvantageState] = useState<AdvantageState>('normal');
    const [bonus, setBonus] = useState(0);
    const [newItem, setNewItem] = useState('');
    const [isRolling, setIsRolling] = useState(false);
    const [rollAnimationValue, setRollAnimationValue] = useState<number | null>(null);
    const [isResultActionable, setIsResultActionable] = useState(false);
    const hpSliderRef = useRef<HTMLInputElement>(null);
    const [equipModal, setEquipModal] = useState<{ item: InventoryItem, index: number } | null>(null);
    const [isSheetModalOpen, setIsSheetModalOpen] = useState(false);

    const handleCharacterUpdate = (updates: Partial<FinalCharacter>) => {
        setCharacter(updates);
    };

    const handleCurrencyChange = (coin: keyof Currency, value: string) => {
        const numValue = parseInt(value) || 0;
        handleCharacterUpdate({ currency: { ...character.currency, [coin]: numValue } });
    };

    const handleAddItem = (e: React.FormEvent) => {
        e.preventDefault();
        if (newItem.trim()) {
            const newItemObject: InventoryItem = { name: newItem.trim() };
            handleCharacterUpdate({ inventory: [...character.inventory, newItemObject] });
            setNewItem('');
        }
    };

    const handleRemoveItem = (indexToRemove: number) => {
        handleCharacterUpdate({
            inventory: character.inventory.filter((_, index) => index !== indexToRemove)
        });
    };

    const handleEquip = (slot: 'weapon' | 'armor') => {
        if (!equipModal) return;
        const { item, index } = equipModal;

        const newInventory = [...character.inventory];
        newInventory.splice(index, 1); // Remove from inventory

        // Unequip current item in slot, if any
        const currentEquipped = slot === 'weapon' ? character.mainWeapon : character.armor;
        if (currentEquipped) {
            newInventory.push(currentEquipped);
        }

        const updates: Partial<FinalCharacter> = { inventory: newInventory };
        if (slot === 'weapon') {
            updates.mainWeapon = item;
        } else {
            updates.armor = item;
        }

        handleCharacterUpdate(updates);
        setEquipModal(null);
    };

    const handleUnequip = (slot: 'weapon' | 'armor') => {
        const itemToUnequip = slot === 'weapon' ? character.mainWeapon : character.armor;
        if (!itemToUnequip) return;
        
        const updates: Partial<FinalCharacter> = {
            inventory: [...character.inventory, itemToUnequip]
        };
        if (slot === 'weapon') {
            updates.mainWeapon = null;
        } else {
            updates.armor = null;
        }
        handleCharacterUpdate(updates);
    };


    const handleRoll = () => {
        if (!selectedDie) return;
        setIsRolling(true);
        setLastRoll(null);
        setIsResultActionable(false);
    
        const animationInterval = setInterval(() => {
            setRollAnimationValue(Math.floor(Math.random() * selectedDie) + 1);
        }, 75);
    
        setTimeout(() => {
            clearInterval(animationInterval);
            setIsRolling(false);
            setRollAnimationValue(null);
    
            let totalBonus = bonus;
            let modifierText = '';
            let bonusText = '';
    
            if (selectedAbilityModifier) {
                const modifierValue = getAbilityModifier(character.stats[selectedAbilityModifier]);
                totalBonus += modifierValue;
                modifierText = ` ${modifierValue >= 0 ? '+' : '-'} ${Math.abs(modifierValue)} [${selectedAbilityModifier.slice(0, 3).toUpperCase()}]`;
            }
            
            if (bonus !== 0) {
                bonusText = ` ${bonus > 0 ? '+' : '-'} ${Math.abs(bonus)}`;
            }
    
            let baseResultText: string;
            let total: number;
    
            if (selectedDie === 20 && advantageState !== 'normal') {
                const roll1 = Math.floor(Math.random() * 20) + 1;
                const roll2 = Math.floor(Math.random() * 20) + 1;
                
                let d20Result: number;
                let discardedRoll: number;
    
                if (advantageState === 'advantage') {
                    d20Result = Math.max(roll1, roll2);
                    discardedRoll = Math.min(roll1, roll2);
                } else { // disadvantage
                    d20Result = Math.min(roll1, roll2);
                    discardedRoll = Math.max(roll1, roll2);
                }
                total = d20Result + totalBonus;
                baseResultText = `${d20Result} (Rolled ${roll1}, ~${discardedRoll}~)`;
            } else {
                const result = Math.floor(Math.random() * selectedDie) + 1;
                total = result + totalBonus;
                baseResultText = `${result}`;
            }
            
            const parts: string[] = [`d${selectedDie}: ${baseResultText}`];
            if (modifierText) parts.push(modifierText);
            if (bonusText) parts.push(bonusText);
            parts.push(` = ${total}`);
    
            let fullResultString = parts.join('');
            setLastRoll(fullResultString);
            setIsResultActionable(true);

        }, 1000);
    };

    const getModifierButtonClass = (ability: Ability) => {
        const baseClass = "transition-all duration-200 rounded-lg font-bold py-2 px-1 flex flex-col items-center justify-center w-full";
        if (selectedAbilityModifier === ability) {
            return `${baseClass} bg-accent text-text-on-accent ring-2 ring-offset-2 ring-offset-black ring-accent-light`;
        }
        return `${baseClass} bg-black/40 hover:bg-black/60 text-text-main`;
    };

    const getAdvantageButtonClass = (isActive: boolean) => {
        const disabledClass = "disabled:opacity-50 disabled:cursor-not-allowed";
        const baseClass = "transition-all duration-200 rounded-lg font-bold py-2 px-2 text-sm capitalize tracking-wider";
        if (isActive) {
            return `${baseClass} bg-accent text-text-on-accent ring-2 ring-offset-2 ring-offset-black ring-accent-light ${disabledClass}`;
        }
        return `${baseClass} bg-black/20 hover:bg-black/40 text-text-main ${disabledClass}`;
    }

    useEffect(() => {
      if (hpSliderRef.current) {
        const percentage = character.maxHp > 0 ? (character.currentHp / character.maxHp) * 100 : 0;
        const p = Math.max(0, Math.min(100, percentage));
        // Hue: 0 is red, 120 is green. We map percentage to this range.
        const hue = (p / 100) * 120; 
        const progressColor = `hsl(${hue}, 90%, 45%)`;
        const trackColor = '#374151'; // Tailwind's gray-700
        
        hpSliderRef.current.style.background = `linear-gradient(to right, ${progressColor} ${p}%, ${trackColor} ${p}%)`;
      }
    }, [character.currentHp, character.maxHp]);

    const EquippedItem: React.FC<{ item: InventoryItem | null; slot: 'weapon' | 'armor' }> = ({ item, slot }) => (
        <div className="bg-black/30 p-2 rounded-lg">
            <h4 className="text-sm font-bold mb-1 text-text-muted">{slot === 'weapon' ? t('mainWeapon') : t('armor')}</h4>
            {item ? (
                <div className="flex justify-between items-center bg-black/20 p-2 rounded">
                    <span className="text-text-main text-sm font-semibold">{item.name}</span>
                    <button onClick={() => handleUnequip(slot)} className="text-accent-light/80 hover:text-accent-dark text-xs font-bold transition-colors">
                        {t('unequip')}
                    </button>
                </div>
            ) : (
                <p className="text-sm text-text-muted/70 text-center py-2 italic">{t('nothingEquipped')}</p>
            )}
        </div>
    );

    return (
        <div className="bg-black/20 p-4 rounded-lg flex flex-col gap-4">
             <CharacterTabs
                characters={characters}
                activeIndex={activeCharacterIndex}
                onSelect={onCharacterChange}
                mainCharacterIndex={mainCharacterIndex}
             />

            {isSheetModalOpen && <DetailsModal character={character} onClose={() => setIsSheetModalOpen(false)} t={t} />}
            {equipModal && <EquipModal item={equipModal.item} onClose={() => setEquipModal(null)} onEquip={handleEquip} t={t} />}

            <div className="flex justify-between items-center bg-black/30 p-3 rounded-lg">
                <div>
                    <h2 className="text-2xl font-bold font-medieval text-text-heading">{character.name}</h2>
                    <p className="text-sm text-text-muted">{`${character.race} ${character.characterClass}`}</p>
                </div>
                <button 
                    onClick={() => setIsSheetModalOpen(true)}
                    className="bg-accent/20 text-accent-light font-bold py-2 px-3 rounded-lg hover:bg-accent/40 transition-colors flex items-center gap-2"
                    title={t('showDetails')}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                        <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.022 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
                    </svg>
                   <span className="hidden xl:inline">{t('showDetails')}</span>
                </button>
            </div>


            {/* Vitals */}
            <div className="grid grid-cols-2 gap-4 text-center">
                <div className="bg-black/30 p-3 rounded-lg">
                    <div className="flex justify-between items-center mb-1">
                        <label className="font-bold text-text-muted/90 block">HP</label>
                        <span className="text-text-muted/90 font-bold font-sans text-xl">
                            {character.currentHp} / {character.maxHp}
                        </span>
                    </div>
                    <input
                        ref={hpSliderRef}
                        type="range"
                        min="0"
                        max={character.maxHp}
                        value={character.currentHp}
                        onChange={e => handleCharacterUpdate({ currentHp: parseInt(e.target.value) || 0 })}
                        className="hp-slider"
                    />
                </div>
                    <div className="bg-black/30 p-3 rounded-lg flex flex-col justify-center">
                    <label className="font-bold text-text-muted/90 block">{t('armorClass')}</label>
                    <input type="number" value={character.armorClass} onChange={e => handleCharacterUpdate({ armorClass: parseInt(e.target.value) || 0 })} className="w-24 mx-auto bg-transparent text-white text-4xl text-center font-bold focus:outline-none" />
                </div>
            </div>

            {/* Equipment */}
            <div className="grid grid-cols-2 gap-2">
                <EquippedItem item={character.mainWeapon} slot="weapon" />
                <EquippedItem item={character.armor} slot="armor" />
            </div>
            
            {/* Rolling Section */}
            <div className="bg-black/30 p-4 rounded-lg grid grid-cols-1 gap-4 items-start">
                <div className="space-y-4">
                    <div>
                        <h4 className="font-bold mb-2 text-center text-text-main">1. {t('selectDie')}</h4>
                        <select
                            value={selectedDie || ''}
                            onChange={(e) => {
                                const value = e.target.value ? parseInt(e.target.value) : null;
                                setSelectedDie(value);
                                if (value !== 20) setAdvantageState('normal');
                            }}
                            className="w-full bg-black/30 border border-accent/20 text-text-main rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-accent/50 text-center font-bold tracking-wider text-md"
                        >
                            <option value="">-- {t('select')} --</option>
                            {DICE_TYPES.map(sides => ( <option key={sides} value={sides}>d{sides}</option>))}
                        </select>
                    </div>
                    <div>
                        <h4 className="font-bold mb-2 text-center text-text-main">2. {t('addModifier')}</h4>
                            <div className="grid grid-cols-6 gap-2">
                            {ABILITIES.map(ability => (
                                <button key={ability} onClick={() => setSelectedAbilityModifier(prev => prev === ability ? null : ability)} className={getModifierButtonClass(ability)}>
                                    <span className="font-bold text-base capitalize">{ability.slice(0,3)}</span>
                                    <span className="font-sans text-xs">{getAbilityModifier(character.stats[ability]) >= 0 ? `+${getAbilityModifier(character.stats[ability])}` : getAbilityModifier(character.stats[ability])}</span>
                                </button>
                            ))}
                        </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <h4 className="font-bold mb-2 text-center text-text-main">3. {t('state')}</h4>
                            <div className="grid grid-cols-3 gap-1">
                                {([
                                    { key: 'N', value: 'normal', label: t('normal') },
                                    { key: 'A', value: 'advantage', label: t('advantage') },
                                    { key: 'D', value: 'disadvantage', label: t('disadvantage') },
                                ] as const).map(({ key, value, label }) => 
                                    <button 
                                        key={key} 
                                        title={label}
                                        onClick={() => setAdvantageState(value)} 
                                        className={getAdvantageButtonClass(advantageState === value)} 
                                        disabled={selectedDie !== 20}
                                    >
                                        {key}
                                    </button>
                                )}
                            </div>
                        </div>
                        <div>
                            <h4 className="font-bold mb-2 text-center text-text-main">4. {t('bonus')}</h4>
                            <input type="number" value={bonus} onChange={e => setBonus(parseInt(e.target.value) || 0)} className="w-full bg-black/20 border border-accent/20 text-text-main rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-accent/50 text-center text-xl font-bold"/>
                        </div>
                    </div>
                </div>
                
                <div className="flex flex-col gap-4 h-full">
                    <button onClick={handleRoll} disabled={!selectedDie || isRolling} className="w-full bg-gradient-to-br from-accent to-accent-dark text-text-on-accent font-bold py-3 px-4 rounded-lg hover:from-accent-dark hover:to-accent-dark transition-all duration-300 disabled:from-accent/50 disabled:to-accent-dark/50 disabled:cursor-not-allowed flex items-center justify-center text-xl tracking-wider">
                        {isRolling ? t('rolling') : t('roll')}
                    </button>
                    <div className="text-center min-h-[4rem] flex flex-col justify-center bg-black/20 p-2 rounded-lg">
                        {isRolling ? ( <p className="text-4xl font-sans font-bold text-white animate-pulse">{rollAnimationValue}</p> ) 
                        : lastRoll ? (
                            <>
                                <p className="text-md font-sans font-bold text-white animate-fade-in whitespace-pre-wrap">{lastRoll}</p>
                                {isResultActionable && (
                                    <button onClick={() => onRoll(lastRoll)} className="mt-2 bg-white hover:bg-gray-200 text-black text-xs font-bold py-1 px-3 rounded-lg transition-colors w-full max-w-xs mx-auto shadow-md">
                                        {t('useRollInAction')}
                                    </button>
                                )}
                            </>
                        ) : ( <p className="text-md text-text-muted/70">{t('resultWillAppear')}</p> )}
                    </div>
                </div>
            </div>
            
            {/* Inventory */}
            <div className="bg-black/30 p-3 rounded-lg">
                <h3 className="text-xl font-bold mb-2 font-medieval bg-gradient-to-b from-accent-light to-accent-dark bg-clip-text text-transparent">{t('inventory')}</h3>
                <div className="space-y-1 max-h-36 overflow-y-auto pr-2">
                    {character.inventory.map((item, index) => (
                        <div key={index} className="flex justify-between items-center bg-black/20 p-2 rounded group">
                            <span className="text-text-main text-sm">{item.name}</span>
                            <div className="flex items-center gap-2">
                                {item.tag && <span className="text-xs bg-accent/20 text-accent-light px-1.5 py-0.5 rounded-full">{item.tag}</span>}
                                <button onClick={() => setEquipModal({ item, index })} className="text-xs font-bold text-accent-light/80 hover:text-accent-dark transition-colors opacity-0 group-hover:opacity-100">{t('equip')}</button>
                                <button onClick={() => handleRemoveItem(index)} className="text-accent-light hover:text-accent-dark text-xl flex-shrink-0">&times;</button>
                            </div>
                        </div>
                    ))}
                    {character.inventory.length === 0 && <p className="text-sm text-text-muted text-center py-2">{t('packIsEmpty')}</p>}
                </div>
                <form onSubmit={handleAddItem} className="flex gap-2 mt-3">
                    <input type="text" value={newItem} onChange={e => setNewItem(e.target.value)} placeholder={t('addNewItem')} className="flex-grow bg-black/20 border border-accent/20 text-text-main rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-accent/50" />
                    <button type="submit" className="bg-gradient-to-br from-accent to-accent-dark text-text-on-accent font-bold px-4 rounded-lg hover:from-accent-dark hover:to-accent-dark">+</button>
                </form>
            </div>

            {/* Wallet & Notes */}
            <div className="flex flex-col gap-4">
                 <div className="bg-black/30 p-3 rounded-lg">
                    <h3 className="text-xl font-bold mb-2 font-medieval bg-gradient-to-b from-accent-light to-accent-dark bg-clip-text text-transparent">{t('wallet')}</h3>
                    <div className="flex justify-around">
                        {Object.keys(character.currency).map(coin => (
                            <div key={coin} className="text-center">
                                <label className="font-bold text-text-muted/90 uppercase text-xs">{coin}</label>
                                <input type="number" value={character.currency[coin as keyof Currency]} onChange={e => handleCurrencyChange(coin as keyof Currency, e.target.value)} className="w-16 bg-transparent text-white text-lg text-center font-bold focus:outline-none" />
                            </div>
                        ))}
                    </div>
                </div>
                 <div className="bg-black/30 p-3 rounded-lg">
                    <h3 className="text-xl font-bold mb-2 font-medieval bg-gradient-to-b from-accent-light to-accent-dark bg-clip-text text-transparent">{t('notes')}</h3>
                    <textarea value={character.notes} onChange={e => handleCharacterUpdate({ notes: e.target.value })} placeholder={t('trackQuests')} className="w-full h-20 bg-black/20 border border-accent/20 text-text-main rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm"></textarea>
                </div>
            </div>

        </div>
    );
};
